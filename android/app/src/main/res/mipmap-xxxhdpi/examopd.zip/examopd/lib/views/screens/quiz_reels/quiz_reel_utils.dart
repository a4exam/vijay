class QuizReelUtils {
  static final subjects = [
    "All",
    "Hindi",
    "English",
    "Math",
    "Reasoning",
    "GS",
  ];
}
