import 'package:flutter/material.dart';
import 'package:get/get.dart';

hSpacer(h) => SizedBox(height: Get.height * h / 1000);

wSpacer(w) => SizedBox(width: Get.width * w / 1000);
