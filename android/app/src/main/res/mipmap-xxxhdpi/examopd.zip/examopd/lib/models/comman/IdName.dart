class IdName {
  String? id;
  String? name;

  IdName({this.id, this.name});
}
