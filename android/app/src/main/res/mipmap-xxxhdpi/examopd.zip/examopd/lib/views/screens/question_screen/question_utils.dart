
class SelectedOption {
  bool isSelected;
  int elapsedSeconds;
  String selectedOptionTitle;

  SelectedOption({
    this.isSelected=false,
    this.elapsedSeconds=0,
    this.selectedOptionTitle='',
  });
}


