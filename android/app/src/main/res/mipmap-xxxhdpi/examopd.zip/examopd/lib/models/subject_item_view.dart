class SubjectItem {
  String? title;
  bool? isSelected;

  SubjectItem({this.title, this.isSelected});
}
