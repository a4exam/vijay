class ResignationUtils {
  static const studentType = 5;
  static const teacherType = 6;
}
