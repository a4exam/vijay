import 'package:mcq/views/components/drop_down/drop_down_utils.dart';


const reportItems = ['Wrong Question', 'Repeat/Mismatch series', 'Both'];

const wrongQuestionItems = ['Hindi', 'English', 'Both'];

const repeatAndMismatchItems = ['Mismatch Series', 'Repeat Question'];
const languageItems = ['English', 'Hindi'];

const issueItems = [
  'aaa',
  'bbb',
  'ccc',
  'ddd',
  'Other'
];

const fontStyleItems = [
  'aaa',
  'bbb',
  'ccc',
  'ddd',
];
