enum Status{
  loading,
  success,
  error
}